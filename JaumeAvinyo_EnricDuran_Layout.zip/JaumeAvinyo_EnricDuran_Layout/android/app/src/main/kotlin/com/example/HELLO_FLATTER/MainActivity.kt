package com.example.HELLO_FLATTER

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
