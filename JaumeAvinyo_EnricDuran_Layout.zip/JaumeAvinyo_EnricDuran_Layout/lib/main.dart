import 'package:flutter/material.dart';

import 'App.dart';

void main() {
  runApp(MyApp());
  // MyApp();
}
